# Step 5: adapters on the deployed model files (route a)

## smoke_qlora_4b (Tier B, unsloth/Qwen3.5-4B, QLoRA)

- converted: 42.5 MB
- loads on Qwen3.5-4B-Q4_K_M.gguf: yes; /lora-adapters: [{'id': 0, 'path': '/tmp/proj/finetune/adapters_gguf/smoke_qlora_4b.gguf', 'scale': 1.0, 'task_name': '', 'prompt_prefix': ''}]
- template: 40/40 prompts identical (rule: at least 95%) -> met
- scale 0: 8/8 replies identical to plain decoding; plain decoding agrees with itself 8/8 -> met
- scale 1 (a look): 0/8 replies equal the training answer word for word; tool calls 0/0; printed markup 0; ended by themselves 8/8

**smoke_qlora_4b: passed**

